# World View Wallpaper Chrome Extension

Experience the world with every tab. Get it free on the [Chrome Extension Store](https://chrome.google.com/webstore/detail/world-view-wallpaper-tab/bdnobddpgjhaenonjkngfhcknndajiia).

Part of the [World View Wallpaper project](http://WorldViewWallpaper.com).

## Contributing

### Bugs? Ideas? Photographs?

Create a new issue by going to Issues -> New Issue! Please try to be as comprehensive as possible, especially when reporting bugs. For example, what Operating System your computer is running, what version of Chrome you're using, and steps we can take to reliably reproduce the bug. This will help us fix the bug faster!

**If you'd like to contribute photograph(s)**, please make sure you own them or they have a fully open source license (allowing for remixing and commercial use). Then, create an issue (issues -> new issue) and drag and drop your image into the issue (or include a download link). Photos must be 2880x1620px (16:9 ratio), compressed to 500kb - 1mb in size (usually around 80% quality).

## Developers

### Running on your computer

Go to `chrome://extensions/`, make sure `developer mode` is enabled, click "load unpacked extension" and select this repo's main folder.

### Locations

Full 24-hour locations are defined in settings.locations, and are stored in their own folders in `/images`.

Highlight images for random modes are defined in `newtab.js`. Stand-alone highlight images that aren't part of a 24 hour set go in `/images/highlights`.

### Deploying

To compress for deploying:
- bump the version number in `manifest.json` and `options.js`
- commit changes to master
- run this from the repository root directory: `git archive -o extension.zip HEAD`

Then, upload `extension.zip` to the [Chrome Developer Dashboard](https://chrome.google.com/webstore/developer/dashboard)
